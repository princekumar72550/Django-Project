 tinymce.init({
        selector: 'textarea'
   });